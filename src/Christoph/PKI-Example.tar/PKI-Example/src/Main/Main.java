package Main;

import java.security.KeyPair;

import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;


import Crypto.*;


public class Main {

		public static void main(String[] args){
			
			try{
				/** Create a new key store **/
				KeyManagement.createKeyStore();

				/** Create a new government key pair and certificate **/
				KeyPair govKeyPair = KeyManagement.generateKeyPair(2048);
				
				X509Certificate govCert =
						PKI.generateSignedCertificate(10, "Government Root CA", "Government Root CA",
														govKeyPair.getPrivate(), govKeyPair.getPublic());
				
				/** Save private key with corresponding certificate chain in key store.
				 ** Certificate corresponding to the private key has to be first in the chain.
				 **/
				KeyManagement.addPrivateKey("GovKey", govKeyPair.getPrivate(),
						new X509Certificate[]{govCert}, "123456");
				
				KeyManagement.addTrustedCertificate("GovCert", govCert);
				
				
				/** Create a new smartcard key pair and certificate **/
				KeyPair scKeyPair = KeyManagement.generateKeyPair(2048);
				
				X509Certificate smartcardCert =
						PKI.generateSignedCertificate(10, "Government Root CA", "Smartcard-1",
														govKeyPair.getPrivate(), scKeyPair.getPublic());
				
				/** Save private key and certificate chain into key store **/
				KeyManagement.addPrivateKey("Smartcard-1", scKeyPair.getPrivate(),
						new X509Certificate[]{smartcardCert, govCert}, "123456");
				
				
				//PKI.printCertificate((X509Certificate) KeyManagement.getKeyStore().getCertificateChain("Smartcard-1")[0]);
				//PKI.printCertificate((X509Certificate) KeyManagement.getKeyStore().getCertificateChain("Smartcard-1")[1]);
				
				/** Verify certificate chain **/
				/** Example of a success **/
				Set<X509Certificate> trustedCerts = new HashSet<X509Certificate>();
				trustedCerts.add((X509Certificate) KeyManagement.getKeyStore().getCertificate("GovCert"));
				
				Certificate[] oldChain = KeyManagement.getKeyStore().getCertificateChain("Smartcard-1");
				X509Certificate[] convertedChain = Arrays.copyOf(oldChain, oldChain.length, X509Certificate[].class);
				
				System.out.println("+++ Verifying smartcard certificate +++");
				if(PKI.verifyCertificateChain(convertedChain, trustedCerts)){
					System.out.println("SUCCESS :)");
				}else{
					System.out.println("FAILURE :(");
				}
				
				
				/** Example of a failure
				  * Note that the private key with which the certificate
				  *  is signed is freshly generated
				 **/
				X509Certificate unknownCert = PKI.generateSignedCertificate(10, "Government Root CA", "Mister Smith",
																			KeyManagement.generateKeyPair(2048).getPrivate(),
																			KeyManagement.generateKeyPair(2048).getPublic());
				X509Certificate[] certificateChain = new X509Certificate[]{unknownCert, govCert};
				
				System.out.println("+++ Verifying unknown certificate +++");
				if(PKI.verifyCertificateChain(certificateChain, trustedCerts)){
					System.out.println("SUCCESS :)");
				}else{
					System.out.println("FAILURE :(");
				}
				
				/** Save certificates into key store **/
				KeyManagement.saveKeyStore("SafeStore", "QWERTY");
				
				/** Unload the key store **/
				KeyManagement.unloadKeyStore();
						
				/** Load key store **/
				KeyManagement.loadKeyStore("SafeStore", "QWERTY");
				PKI.printCertificate((X509Certificate) KeyManagement.getKeyStore().getCertificate("GovCert"));
				
			}catch(Exception e){
				e.printStackTrace();
			}
	            
		}
}
