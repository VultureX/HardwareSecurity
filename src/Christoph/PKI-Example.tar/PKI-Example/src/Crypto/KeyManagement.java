package Crypto;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import org.bouncycastle.jce.provider.BouncyCastleProvider;

/**
 * @author Krzysztof Okupski
 * @version 1.0
 */
public final class KeyManagement {

	// private static KeyManagement instance = null;
	private static KeyStore keyStore;

	static {
		Security.addProvider(new BouncyCastleProvider());
	}

	private KeyManagement() {
		keyStore = null;
	}

	/*
	 * public static synchronized KeyManagement getInstance() { if (instance ==
	 * null) { instance = new KeyManagement(); } return instance; }
	 */

	private static boolean isInitialized() {
		if (keyStore != null) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * @param keySize
	 *            Key size in bits.
	 * @return Private-public key pair or null.
	 */
	public final static KeyPair generateKeyPair(int keySize) {

		assert (keySize > 0 && keySize <= 4096);

		KeyPairGenerator keyPairGenerator = null;
		KeyPair keyPair = null;

		try {
			keyPairGenerator = KeyPairGenerator.getInstance("RSA", "BC");
			keyPairGenerator.initialize(keySize, new SecureRandom());
			keyPair = keyPairGenerator.generateKeyPair();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return keyPair;
	}

	/**
	 * Saves private key with corresponding certificate chain in key store.
	 * Certificate corresponding to the private key has to be first in the
	 * chain.
	 * 
	 * @param keyAlias
	 *            Alias for the private key.
	 * @param privKey
	 *            Private key to be stored.
	 * @param password
	 *            Password to the key store.
	 */
	public final static void addPrivateKey(String keyAlias, PrivateKey privKey,
			X509Certificate[] certChain, String password) {

		assert (keyAlias != null);
		assert (privKey != null);

		if (!isInitialized()) {
			System.out.println("Key store is not initialized");
			return;
		}

		KeyStore.PrivateKeyEntry privKeyEntry = new KeyStore.PrivateKeyEntry(
				privKey, certChain);

		try {
			keyStore.setEntry(keyAlias, privKeyEntry,
					new KeyStore.PasswordProtection(password.toCharArray()));
		} catch (KeyStoreException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @param certAlias
	 *            Alias for the certificate.
	 * @param cert
	 *            X509 Certificate to be stored.
	 */
	public final static void addTrustedCertificate(String certAlias,
			X509Certificate cert) {

		if (!isInitialized()) {
			System.out.println("Key store is not initialized");
			return;
		}

		try {
			keyStore.setCertificateEntry(certAlias, cert);
		} catch (KeyStoreException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Creates a new and empty key store.
	 */
	public final static void createKeyStore() {

		try {
			keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
			keyStore.load(null, null);

		} catch (KeyStoreException e) {
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (CertificateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @param keyStoreName
	 *            Name of the key store.
	 * @param password
	 *            Password to the key store.
	 */
	public final static void loadKeyStore(String keyStoreName, String password) {

		FileInputStream fis = null;

		try {
			keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
			fis = new FileInputStream(keyStoreName);

			keyStore.load(fis, password.toCharArray());

			if (fis != null) {
				fis.close();
			}

		} catch (KeyStoreException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (CertificateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Saves the key store into a file.
	 * 
	 * @param keyStoreName
	 *            Name of the key store.
	 * @param password
	 *            Password for keystore protection.
	 */
	public final static void saveKeyStore(String keyStoreName, String password) {

		FileOutputStream fos = null;

		try {
			fos = new FileOutputStream(keyStoreName);
			keyStore.store(fos, password.toCharArray());

			if (fos != null) {
				fos.close();
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (KeyStoreException e) {
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (CertificateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Unloads the key store.
	 */
	public final static void unloadKeyStore() {
		if (keyStore != null) {
			keyStore = null;
		}
	}

	/**
	 * @return Fetches the key store.
	 */
	public static final KeyStore getKeyStore() {
		return keyStore;
	}

}
