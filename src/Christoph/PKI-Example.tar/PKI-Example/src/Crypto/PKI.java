package Crypto;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Security;
import java.security.SignatureException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Date;
import java.util.Set;

import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.X509v1CertificateBuilder;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.PEMWriter;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;

import com.google.common.base.Strings;

/**
 * @author Krzysztof Okupski
 * @version 1.0
 */
public final class PKI {

	static {
		Security.addProvider(new BouncyCastleProvider());
	}

	/**
	 * Creates a certificate signed with the signerPrivateKey. If the
	 * certificate is to be self-signed, then pass the public key corresponding
	 * to signerPrivateKey.
	 * 
	 * @param validityTime
	 *            Validity time in days
	 * @param issuerName
	 *            Distinguished name of the issuer
	 * @param issuedName
	 *            Distinguished name of the issued
	 * @param signingPrivateKey
	 *            Private key of the signing party
	 * @param signedPublicKey
	 *            Public key of the signed party
	 * @return X509v3 Certificate on success or null on fail.
	 */
	public final static X509Certificate generateSignedCertificate(
			int validityTime, String issuerName, String issuedName,
			PrivateKey signingPrivateKey, PublicKey signedPublicKey) {

		assert (validityTime > 0);
		assert (issuerName != null);
		assert (issuedName != null);
		assert (signingPrivateKey != null);
		assert (signedPublicKey != null);

		X509Certificate cert = null;

		Date validityBeginDate = new Date(System.currentTimeMillis());
		Date validityEndDate = new Date(System.currentTimeMillis()
				+ validityTime * 24 * 60 * 60 * 1000);

		ContentSigner sigGen;
		JcaX509CertificateConverter certConverter;
		try {
			sigGen = new JcaContentSignerBuilder("SHA1withRSA").setProvider(
					"BC").build(signingPrivateKey);
			certConverter = new JcaX509CertificateConverter().setProvider("BC");
		} catch (Exception e) {
			return cert;
		}

		SubjectPublicKeyInfo subPubKeyInfo = new SubjectPublicKeyInfo(
				ASN1Sequence.getInstance(signedPublicKey.getEncoded()));

		X509v1CertificateBuilder v1CertGen = new X509v1CertificateBuilder(
				new X500Name("CN=" + issuerName), BigInteger.ONE,
				validityBeginDate, validityEndDate, new X500Name("CN="
						+ issuedName), subPubKeyInfo);

		X509CertificateHolder certHolder = v1CertGen.build(sigGen);
		try {
			cert = certConverter.getCertificate(certHolder);
			return cert;
		} catch (CertificateException e) {
			return cert;
		}
	}

	public static boolean verifyCertificateChain(X509Certificate[] certChain,
			Set<X509Certificate> trustedCerts) {

		assert (certChain != null);

		try {

			for (int i = 0; i < certChain.length; i++) {
				if (trustedCerts.contains(certChain[i])) {
					return true;
				}

				if (i < certChain.length - 1) {
					/* Check if preceding certificate is signer */
					certChain[i].verify(certChain[i + 1].getPublicKey());
				} else {
					/* Check if last certificate is self-signed */
					certChain[i].verify(certChain[i].getPublicKey());
				}
			}

		} catch (InvalidKeyException e) {
			System.out.println("Incorrect key");
			return false;
		} catch (CertificateException e) {
			System.out.println("Encoding error");
			return false;
		} catch (NoSuchAlgorithmException e) {
			System.out.println("Unsupported signature algorithm");
			return false;
		} catch (NoSuchProviderException e) {
			System.out.println("No default provider");
			return false;
		} catch (SignatureException e) {
			System.out.println("Signature error.");
			return false;
		}

		return false;
	}

	/**
	 * @param signedCert
	 *            Signed X509 certificate to be verified
	 * @param rootCert
	 *            Root certificate that signed signedCert
	 * @return Returns true if signedCert was signed by rootCert.
	 */
	public static boolean isSignedByRootCert(X509Certificate signedCert,
			X509Certificate rootCert) {

		assert (signedCert != null);
		assert (rootCert != null);

		try {
			PublicKey pkRootCert = rootCert.getPublicKey();
			signedCert.verify(pkRootCert);
			return true;
		} catch (SignatureException sigEx) {
			/** Invalid signature **/
			sigEx.printStackTrace();
			return false;
		} catch (InvalidKeyException e) {
			/** Invalid key **/
			e.printStackTrace();
			return false;
		} catch (CertificateException e) {
			e.printStackTrace();
			return false;
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			return false;
		} catch (NoSuchProviderException e) {
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * @param cert
	 *            X509 Certificate to be verified
	 * @return True if certificate is self-signed. False otherwise.
	 */
	public static boolean isSelfSigned(X509Certificate cert) {

		assert (cert != null);

		PublicKey pubKey;

		try {
			pubKey = cert.getPublicKey();
			cert.verify(pubKey);
			return true;
		} catch (SignatureException sigEx) {
			// Invalid signature --> not self-signed
			return false;
		} catch (InvalidKeyException keyEx) {
			// Invalid key --> not self-signed
			return false;
		} catch (CertificateException e) {
			return false;
		} catch (NoSuchAlgorithmException e) {
			return false;
		} catch (NoSuchProviderException e) {
			return false;
		}
	}

	/**
	 * @param cert
	 *            X509 Certificate to be printed
	 */
	public final static void printCertificate(Certificate cert) {
		assert (cert != null);

		System.out.println(Strings.repeat("=", 80));
		System.out.println("CERTIFICATE TO_STRING");
		System.out.println(Strings.repeat("=", 80));
		System.out.println();
		System.out.println(cert);
		System.out.println();

		System.out.println(Strings.repeat("=", 80));
		System.out.println("CERTIFICATE PEM");
		System.out.println(Strings.repeat("=", 80));
		System.out.println();

		PEMWriter pemWriter = new PEMWriter(new PrintWriter(System.out));
		try {
			pemWriter.writeObject(cert);
			pemWriter.flush();
			pemWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
			return;
		}

		System.out.println();
	}
}
